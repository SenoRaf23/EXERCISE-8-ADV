import { initializeApp } from "firebase/app";

const firebaseConfig = {
    apiKey: "AIzaSyCXqp-2aLga5FATx61kHrduTnx83H6p8gQ",
    authDomain: "adv-registerform.firebaseapp.com",
    projectId: "adv-registerform",
    storageBucket: "adv-registerform.appspot.com",
    messagingSenderId: "186955183649",
    appId: "1:186955183649:web:169d9288c3574846091560",
    measurementId: "G-5W9NHEJ2WL"
  };
  
const app = initializeApp(firebaseConfig);

export default app;
